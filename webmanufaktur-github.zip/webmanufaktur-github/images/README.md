# Bilder

Lade hier dein Logo hoch und nenne die Datei **logo.png**.

- Empfohlen: PNG mit transparentem Hintergrund (alternativ: logo.svg, siehe README im Hauptordner)
- Empfohlene Höhe: ca. 80–120 px (wird auf der Website auf 40 px Höhe angezeigt)

Solange hier keine Datei `logo.png` liegt, zeigt die Website automatisch das Standard-Symbol.
